#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <wait.h>

void dieWithError(char *);

void greet(char myName) {
  printf("Process %c, PID %d greets you.\n",myName,getpid());
  fflush(stdout);
}


int main() {

  /* YOUR CODE HERE -- See instructions */

  return 0;
}
